module.exports = {
  port : '3000',
  public: '/public',
  db: {
    host: 'localhost',
    name: 'jarvis',
    port: '27017'
  }
};